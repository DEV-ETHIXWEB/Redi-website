<?php
/**
 * Plugin Name:       REDI Home Editor
 * Description:       Puts the home page text into wp-admin. Adds a "Home Page (REDI)" page whose fields drive the live home page, and serves them to the frontend. Any field left empty keeps the copy already on the site.
 * Version:           1.0.0
 * Author:            Ethixweb
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Why this exists
 * ---------------
 * The home page text was not editable in WordPress. There was no Home page at
 * all, and the frontend never read /wp/v2/pages, so an editor looking at the
 * Pages screen had nothing to open. Every wording change had to come back to
 * the developers.
 *
 * Why it is NOT built on redi/v1/page-copy
 * ----------------------------------------
 * That route exists and returns the whole page-copy tree, but it is a frozen
 * export: its response matched this repo's seed as committed on 2026-09-04 and
 * has never changed since, because nothing in wp-admin edits it. For a month
 * it also silently overrode newer approved copy on the live site, because the
 * frontend merged it with WordPress winning. Pointing the editor at that route
 * would rebuild the same trap.
 *
 * So this uses real, editable ACF fields on a real page, and the frontend
 * treats them as an overlay rather than a replacement.
 *
 * The rule that stops it happening again
 * --------------------------------------
 * A field only overrides the site when an editor has actually typed something
 * into it. Blank means "leave the approved copy alone", never "blank the
 * section". That is the single difference between this and the export it
 * replaces: a half-filled screen can never empty the home page.
 *
 * ACF here is the free edition, so no Options Pages and no Repeaters. Hence a
 * real page rather than an options screen, and paragraphs entered as one
 * textarea split on blank lines rather than a repeater.
 */

const REDI_HOME_SLUG      = 'redi-home';
const REDI_HOME_ID_OPTION = 'redi_home_editor_page_id';

/** Current approved copy, used to pre-fill the fields on first activation. */
function redi_home_defaults() {
	return array(
		'hero_kicker' => '',
		'hero_headline' => 'The National Standard for Site Readiness',
		'hero_paragraphs' => 'Companies making location decisions move fast and eliminate sites early. Most sites are not ruled out because they are bad sites. They are ruled out because key information is missing, unclear or unverified when a site selector needs it.

REDI Sites is the first national site readiness designation program in the United States, developed in affiliation with the Site Selectors Guild. Every site that completes the process receives a designation reflecting its current level of investment readiness, telling site selectors exactly where it stands, and telling you what to do next.',
		'hero_cta_primary' => 'Explore Sites',
		'hero_cta_secondary' => 'Register Your Site',
		'sov_eyebrow' => 'What We Deliver',
		'sov_heading' => 'Statement of Value',
		'sov_paragraphs' => 'REDI Sites empowers communities to compete for investment. We evaluate industrial sites against one consistent national standard, developed and governed by the Site Selectors Guild and informed by the expertise of active Certified Site Selection Consultants®. Each site is reviewed across utilities, environmental, ownership and entitlements, ease of development, and logistics, so its readiness is documented, not assumed.

Every site that completes the process receives a designation that reflects where it stands today, from Emerging to Platinum. Every level is an achievement. Each designation comes with actionable feedback and a clear path to improve and advance, giving communities a roadmap for their readiness journey and site selectors credible, up-to-date site intelligence they can trust.

Designated sites are searchable on a public platform that puts qualified properties in front of companies, brokers, and site selection professionals, with the documentation to back them up. With REDI Sites, your site isn\'t just a dot on a map. It\'s ready to be found, and ready to compete.',
		'why_eyebrow' => 'The Value',
		'why_heading' => 'Why Designate a Site?',
		'why_body' => 'A REDI Sites designation puts your site in front of the people who move projects forward, and gives you a clear plan for what comes next.',
		'score_eyebrow' => 'Site Rating System',
		'score_heading' => 'The REDI Score',
		'score_body' => 'Every site is scored on a 10-point readiness scale built from five weighted categories: utilities, ownership and entitlements, environmental, ease of development, and logistics. The score reflects documented, verified readiness.',
		'cta_heading' => 'Is your site ready?',
		'cta_body' => 'Take the first step toward a REDI Sites designation and greater credibility, visibility, and investment readiness.',
		'cta_label' => 'Register your site',
	);
}

/* -------------------------------------------------------------------------
 * 1. The page itself
 * ---------------------------------------------------------------------- */

/**
 * Creates the page on activation and fills it with the copy that is live, so
 * an editor opens real text rather than empty boxes and can see what they are
 * changing. Runs once; re-activating will not overwrite edited values.
 */
function redi_home_editor_activate() {
	$existing = get_page_by_path( REDI_HOME_SLUG, OBJECT, 'page' );

	if ( $existing ) {
		update_option( REDI_HOME_ID_OPTION, $existing->ID );
		return;
	}

	$page_id = wp_insert_post(
		array(
			'post_title'   => 'Home Page (REDI)',
			'post_name'    => REDI_HOME_SLUG,
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_content' => '',
		)
	);

	if ( is_wp_error( $page_id ) || ! $page_id ) {
		return;
	}

	update_option( REDI_HOME_ID_OPTION, $page_id );

	// Pre-fill. update_field() needs ACF; if it is not loaded yet the fields
	// simply stay empty, which the frontend reads as "keep the approved copy".
	if ( function_exists( 'update_field' ) ) {
		foreach ( redi_home_defaults() as $name => $value ) {
			update_field( $name, $value, $page_id );
		}
	}
}
register_activation_hook( __FILE__, 'redi_home_editor_activate' );

/** The page being edited, or 0 before activation has run. */
function redi_home_page_id() {
	$id = (int) get_option( REDI_HOME_ID_OPTION, 0 );
	if ( $id && get_post( $id ) ) {
		return $id;
	}
	$page = get_page_by_path( REDI_HOME_SLUG, OBJECT, 'page' );
	return $page ? $page->ID : 0;
}

/* -------------------------------------------------------------------------
 * 2. The fields
 * ---------------------------------------------------------------------- */

add_action(
	'acf/init',
	function () {
		if ( ! function_exists( 'acf_add_local_field_group' ) ) {
			return; // ACF inactive - fail quiet rather than fatal.
		}

		$page_id = redi_home_page_id();
		if ( ! $page_id ) {
			return;
		}

		$text = function ( $key, $label, $name, $instructions = '' ) {
			return array(
				'key'          => 'field_redi_home_' . $key,
				'label'        => $label,
				'name'         => $name,
				'type'         => 'text',
				'instructions' => $instructions,
			);
		};
		$area = function ( $key, $label, $name, $instructions = '', $rows = 5 ) {
			return array(
				'key'          => 'field_redi_home_' . $key,
				'label'        => $label,
				'name'         => $name,
				'type'         => 'textarea',
				'rows'         => $rows,
				'new_lines'    => '',
				'instructions' => $instructions,
			);
		};

		$blank = 'Leave empty to keep what is on the site now.';
		$split = 'One paragraph per block, separated by a blank line. ' . $blank;

		acf_add_local_field_group(
			array(
				'key'          => 'group_redi_home_editor',
				'title'        => 'Home Page Content',
				'menu_order'   => 0,
				'position'     => 'normal',
				'active'       => true,
				'show_in_rest' => 1,
				'instructions' => '',
				'location'     => array(
					array(
						array(
							'param'    => 'page',
							'operator' => '==',
							'value'    => $page_id,
						),
					),
				),
				'fields'       => array(
					array(
						'key'   => 'field_redi_home_tab_hero',
						'label' => 'Hero',
						'type'  => 'tab',
					),
					$text( 'hero_kicker', 'Kicker', 'hero_kicker', 'Small line above the headline. ' . $blank ),
					$text( 'hero_headline', 'Headline', 'hero_headline', $blank ),
					$area( 'hero_paragraphs', 'Paragraphs', 'hero_paragraphs', $split, 6 ),
					$text( 'hero_cta_primary', 'Primary button label', 'hero_cta_primary', $blank ),
					$text( 'hero_cta_secondary', 'Secondary button label', 'hero_cta_secondary', $blank ),

					array(
						'key'   => 'field_redi_home_tab_sov',
						'label' => 'Statement of Value',
						'type'  => 'tab',
					),
					$text( 'sov_eyebrow', 'Eyebrow', 'sov_eyebrow', $blank ),
					$text( 'sov_heading', 'Heading', 'sov_heading', $blank ),
					$area( 'sov_paragraphs', 'Paragraphs', 'sov_paragraphs', $split, 10 ),

					array(
						'key'   => 'field_redi_home_tab_why',
						'label' => 'Why Designate a Site',
						'type'  => 'tab',
					),
					$text( 'why_eyebrow', 'Eyebrow', 'why_eyebrow', $blank ),
					$text( 'why_heading', 'Heading', 'why_heading', $blank ),
					$area( 'why_body', 'Intro text', 'why_body', $blank, 4 ),

					array(
						'key'   => 'field_redi_home_tab_score',
						'label' => 'REDI Score',
						'type'  => 'tab',
					),
					$text( 'score_eyebrow', 'Eyebrow', 'score_eyebrow', $blank ),
					$text( 'score_heading', 'Heading', 'score_heading', $blank ),
					$area( 'score_body', 'Intro text', 'score_body', $blank, 4 ),

					array(
						'key'   => 'field_redi_home_tab_cta',
						'label' => 'Closing banner',
						'type'  => 'tab',
					),
					$text( 'cta_heading', 'Heading', 'cta_heading', $blank ),
					$area( 'cta_body', 'Body', 'cta_body', $blank, 3 ),
					$text( 'cta_label', 'Button label', 'cta_label', $blank ),
				),
			)
		);
	}
);

/** Hides the block editor on this page: the fields are the content. */
add_filter(
	'use_block_editor_for_post',
	function ( $use, $post ) {
		if ( $post instanceof WP_Post && (int) $post->ID === redi_home_page_id() ) {
			return false;
		}
		return $use;
	},
	10,
	2
);

/* -------------------------------------------------------------------------
 * 3. The route the frontend reads
 * ---------------------------------------------------------------------- */

/** Trimmed string, or null when the editor has not filled this one in. */
function redi_home_value( $name, $page_id ) {
	if ( ! function_exists( 'get_field' ) ) {
		return null;
	}
	$value = get_field( $name, $page_id );
	if ( ! is_string( $value ) ) {
		return null;
	}
	$value = trim( $value );
	return '' === $value ? null : $value;
}

/** Blank-line separated text to a list, or null when nothing was entered. */
function redi_home_paragraphs( $name, $page_id ) {
	$value = redi_home_value( $name, $page_id );
	if ( null === $value ) {
		return null;
	}
	$parts = preg_split( '/\R\s*\R/', $value );
	$parts = array_values( array_filter( array_map( 'trim', $parts ), 'strlen' ) );
	return $parts ? $parts : null;
}

/**
 * Own namespace, not redi/v1. That namespace belongs to REDI Headless CMS, and
 * sharing it risks a name collision the day it adds a route of its own.
 *
 * Every key can be null, and null means "the editor did not set this". The
 * frontend keeps its approved value for anything null, so a partly filled
 * screen degrades to the current site rather than to blanks.
 */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'ethixweb/v1',
			'/home-copy',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true', // public: same copy the page already shows
				'callback'            => function () {
					$id = redi_home_page_id();
					if ( ! $id ) {
						return rest_ensure_response( array() );
					}

					return rest_ensure_response(
						array(
							'hero'             => array(
								'kicker'     => redi_home_value( 'hero_kicker', $id ),
								'headline'   => redi_home_value( 'hero_headline', $id ),
								'paragraphs' => redi_home_paragraphs( 'hero_paragraphs', $id ),
								'ctaPrimaryLabel'   => redi_home_value( 'hero_cta_primary', $id ),
								'ctaSecondaryLabel' => redi_home_value( 'hero_cta_secondary', $id ),
							),
							'statementOfValue' => array(
								'eyebrow'    => redi_home_value( 'sov_eyebrow', $id ),
								'heading'    => redi_home_value( 'sov_heading', $id ),
								'paragraphs' => redi_home_paragraphs( 'sov_paragraphs', $id ),
							),
							'whyChoose'        => array(
								'eyebrow' => redi_home_value( 'why_eyebrow', $id ),
								'heading' => redi_home_value( 'why_heading', $id ),
								'body'    => redi_home_value( 'why_body', $id ),
							),
							'rediScore'        => array(
								'eyebrow' => redi_home_value( 'score_eyebrow', $id ),
								'heading' => redi_home_value( 'score_heading', $id ),
								'body'    => redi_home_value( 'score_body', $id ),
							),
							'ctaInvest'        => array(
								'heading'  => redi_home_value( 'cta_heading', $id ),
								'body'     => redi_home_value( 'cta_body', $id ),
								'ctaLabel' => redi_home_value( 'cta_label', $id ),
							),
						)
					);
				},
			)
		);
	}
);

/* -------------------------------------------------------------------------
 * 4. Rebuild the site when the page is saved
 * ---------------------------------------------------------------------- */

/**
 * REDI Auto Deploy watches the five content post types, not pages, so saving
 * this one would otherwise change nothing until the next unrelated publish.
 */
add_action(
	'acf/save_post',
	function ( $post_id ) {
		if ( is_numeric( $post_id ) && (int) $post_id === redi_home_page_id() && function_exists( 'redi_deploy_schedule' ) ) {
			redi_deploy_schedule();
		}
	},
	20
);
